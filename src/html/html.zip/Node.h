﻿#ifndef __HTML_PARSER_NODE_H
#define __HTML_PARSER_NODE_H

#include <map>
#include <string>
#include <utility>

namespace htmlcxx {
	namespace HTML {
		class Node {

			public:
				Node() {}
				//Node(const Node &rhs); //uses default
				~Node() {}

				/** 开始标签 */
				inline void text(const std::string& text) { this->mText = text; }
				inline const std::string& text() const { return this->mText; }

				/** 结尾标签 */
				inline void closingText(const std::string &text) { this->mClosingText = text; }
				inline const std::string& closingText() const { return mClosingText; }

				/** 标签在整个文档中的偏移量(首字符<) */
				inline void offset(unsigned int offset) { this->mOffset = offset; }
				inline unsigned int offset() const { return this->mOffset; }

				/** 开始标签长度 如:<html class="oaded"> 长度为21  */
				inline void length(unsigned int length) { this->mLength = length; }
				inline unsigned int length() const { return this->mLength; }

				/** 标签名 */
				inline void tagName(const std::string& tagname) { this->mTagName = tagname; }
				inline const std::string& tagName() const { return this->mTagName; }

				/** 判断是不是标签(还有注释) */
				bool isTag() const { return this->mIsHtmlTag; }
				void isTag(bool is_html_tag){ this->mIsHtmlTag = is_html_tag; }

				/** 判断是不是注释(还有标签) */
				bool isComment() const { return this->mComment; }
				void isComment(bool comment){ this->mComment = comment; }

				std::pair<bool, std::string> attribute(const std::string &attr) const
				{ 
					std::map<std::string, std::string>::const_iterator i = this->mAttributes.find(attr);
					if (i != this->mAttributes.end()) {
						return make_pair(true, i->second);
					} else {
						return make_pair(false, std::string());
					}
				}

				/** 如果是标签节点则返回标签名，否则返回标签文本 */
				operator std::string() const;
				std::ostream &operator<<(std::ostream &stream) const;

				/** 获取标签所有属性，必须先调用parAttributes解析属性 */
				const std::map<std::string, std::string>& attributes() const { return this->mAttributes; }
				/** 解析标签属性 */
				void parseAttributes();

				bool operator==(const Node &rhs) const;

			protected:

				std::string mText;										/*!> 标签完整文本(<a href="xxxxx">)*/
				std::string mClosingText;								/*!> 结尾标签文本(</a>)*/
				unsigned int mOffset;									/*!> 标签在文档中的偏移量*/
				unsigned int mLength;									/*!> 标签完整长度(mText.size())*/
				std::string mTagName;									/*!> 标签名(a、p、div等)*/
				std::map<std::string, std::string> mAttributes;			/*!> 标签所有属性*/
				bool mIsHtmlTag;										/*!> 是否是标签节点*/
				bool mComment;											/*!> 是否是注释节点*/
		};
	}
}

#endif
